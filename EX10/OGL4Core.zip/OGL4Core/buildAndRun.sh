
cd Plugins
make
if [ $? = 0 ];
then
  cd ..
  ./ogl4coreGLUT64d -rid 1
fi
