// Supersampling.cpp 
//

#include <GL/gl3w.h>

#include "GLHelpers.h"
#include "stdafx.h"
#include "Supersampling.h"
#include <vector>
#include <iostream>
#include <fstream>
#include <string>
#include <gtc/matrix_transform.hpp>
#include <gtc/type_ptr.hpp>
#include <cstdlib>
#define _USE_MATH_DEFINES
#include <math.h>

Supersampling::Supersampling(COGL4CoreAPI *Api) : RenderPlugin(Api) {
  this->myName = "MyPlugins/Supersampling";
  this->myDescription = "Supersampling of a checkerboard.";
}

Supersampling::~Supersampling() {
}

void GenerateGroundMesh(std::vector<glm::vec4> &verts_ground, 
		      std::vector<glm::vec4> &colors_ground, 
		      unsigned int &numVerts_ground, 
		      std::vector<unsigned int> &indices_ground, 
		      unsigned int &numIndices_ground)
{
  verts_ground.resize(0);
  colors_ground.resize(0);
  indices_ground.resize(0);

  verts_ground.push_back(glm::vec4(-5.0f,0.0f,-5.0f,1.0f));
  verts_ground.push_back(glm::vec4( 5.0f,0.0f,-5.0f,1.0f));
  verts_ground.push_back(glm::vec4( 5.0f,0.0f, 5.0f,1.0f));
  verts_ground.push_back(glm::vec4(-5.0f,0.0f, 5.0f,1.0f));

  colors_ground.push_back(glm::vec4(0.7f,0.7f,0.7f,1.0f));
  colors_ground.push_back(glm::vec4(0.7f,0.7f,0.7f,1.0f));
  colors_ground.push_back(glm::vec4(0.7f,0.7f,0.7f,1.0f));
  colors_ground.push_back(glm::vec4(0.7f,0.7f,0.7f,1.0f));

  indices_ground.push_back(0);
  indices_ground.push_back(2);
  indices_ground.push_back(1);
  indices_ground.push_back(2);
  indices_ground.push_back(0);
  indices_ground.push_back(3);

  numVerts_ground = verts_ground.size();
  numIndices_ground = indices_ground.size();
}

const std::string LoadShaderText(const char* filename)
{
  std::cout <<  filename << std::endl;
  std::string shaderText;
  std::ifstream file(filename);  
  std::string line;

  if (file.good()) {
    // read the shader file line by line
    while (getline(file, line)) {
      shaderText += line;
      shaderText += '\n';
    }
  }

  return shaderText;
}

GLuint Supersampling::CreateShaderProgram(const char *vertShaderFileName, const char *fragShaderFileName)
{
  GLuint vertexShader;
  GLuint fragmentShader;
  GLuint program;

  const std::string vertexShaderText = LoadShaderText(vertShaderFileName);
  const std::string fragmentShaderText = LoadShaderText(fragShaderFileName);

  vertexShader = glCreateShader(GL_VERTEX_SHADER);
  fragmentShader = glCreateShader(GL_FRAGMENT_SHADER);
  program = glCreateProgram();

  const GLchar *vertexShaderSources[1] = {vertexShaderText.c_str()};
  const GLchar *fragmentShaderSources[1] = {fragmentShaderText.c_str()};

  glShaderSource(vertexShader, 1, vertexShaderSources, NULL);
  glShaderSource(fragmentShader, 1, fragmentShaderSources, NULL);

  GLint success;
  const unsigned int MAX_INFO_LOG_SIZE = 2048;

  // Compile vertex shader and check if succeeded
  glCompileShader(vertexShader);
  glGetShaderiv(vertexShader, GL_COMPILE_STATUS, &success);
  if (!success) {
    GLchar infoLog[MAX_INFO_LOG_SIZE];
    glGetShaderInfoLog(vertexShader, MAX_INFO_LOG_SIZE, NULL, infoLog);
    std::cerr << "Error in vertex shader compilation. Info log:" << std::endl;
    std::cerr << infoLog << std::endl;
    return 0;
  }
  // Compile fragment shader and check if succeeded
  glCompileShader(fragmentShader);
  glGetShaderiv(fragmentShader, GL_COMPILE_STATUS, &success);
  if (!success) {
    GLchar infoLog[MAX_INFO_LOG_SIZE];
    glGetShaderInfoLog(fragmentShader, MAX_INFO_LOG_SIZE, NULL, infoLog);
    std::cerr << "Error in fragment shader compilation. Info log:" << std::endl;
    std::cerr << infoLog << std::endl;
    return 0;
  }

  // Attach shaders to program
  glAttachShader(program, vertexShader);
  glAttachShader(program, fragmentShader);

  // Link program and check if succeeded
  glLinkProgram(program);
  glGetProgramiv(program, GL_LINK_STATUS, &success);
  if (!success) {
    GLchar infoLog[MAX_INFO_LOG_SIZE];
    glGetProgramInfoLog(program, MAX_INFO_LOG_SIZE, NULL, infoLog);
    std::cerr << "Error in program linkage. Info log:" << std::endl;
    std::cerr << infoLog << std::endl;
    return 0;
  }

  glDeleteShader(vertexShader);
  glDeleteShader(fragmentShader);

  return program;
}

void Supersampling::GenerateGround()
{
  // holds vertex positions of the triangles the ground is made of
  std::vector<glm::vec4> verts_ground;
  // holds vertex indices; used to generate triangles from an array of vertices
  std::vector<unsigned int> indices_ground;
  // holds colors for the trunk and crown vertices
  std::vector<glm::vec4> colors_ground;
  
  // Generate geometry for the ground: traingle vertices, vertex indices
  GenerateGroundMesh(verts_ground, colors_ground, numVerts_ground,
		     indices_ground, numIndices_ground);
  
  // Generate buffers that will hold the vertex and index data
  glGenVertexArrays(1,&va_ground);
  glGenBuffers(1,&vbo_ground);
  glGenBuffers(1,&ibo_ground);
  glGenBuffers(1,&cbo_ground);
  
  // Bind vertex array; bind buffers to this array and load data 
  // from verts_ground and indices_ground
  glBindVertexArray(va_ground);
    glBindBuffer(GL_ARRAY_BUFFER,vbo_ground);
    // Enable vertex attribute array (in vertex shader accessible 
    // from layout (location = 0) in vec4 position;)
    glEnableVertexAttribArray(0);
    glBufferData(GL_ARRAY_BUFFER,sizeof(glm::vec4)*numVerts_ground, 
		 verts_ground.data(),GL_STATIC_DRAW);
    // Specify data format for this vertex attribute array
    glVertexAttribPointer(0,4,GL_FLOAT,GL_FALSE,0,NULL);

    glBindBuffer(GL_ARRAY_BUFFER,cbo_ground);
    // Enable vertex attribute array
    glEnableVertexAttribArray(1);
    glBufferData(GL_ARRAY_BUFFER,sizeof(glm::vec4)*numVerts_ground, 
		 colors_ground.data(),GL_STATIC_DRAW);
    // Specify data format for this vertex attribute array
    glVertexAttribPointer(1,4,GL_FLOAT,GL_FALSE,0,NULL);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo_ground);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(unsigned int)*numIndices_ground, 
		 indices_ground.data(), GL_STATIC_DRAW);
  // Unbind vertex array
  glBindVertexArray(0);

  //-----------------------------------------
  // Create shader program for ground rendering
  std::string baseDir = this->GetCurrentPluginPath();
  std::string vertShaderFile = baseDir+"/resources/shaders/GroundVertex.glsl";
  std::string fragShaderFile = baseDir+"/resources/shaders/GroundFragment.glsl";

  shaderProgram_ground = CreateShaderProgram(vertShaderFile.c_str(), fragShaderFile.c_str());
}

void Supersampling::initiateGuiList() {
  
  checkerboardFrequencyX.Set(this, "checkerboardFrequencyX");
  checkerboardFrequencyX.Register("step=5.0 min=1.0 max=1000.0");
  checkerboardFrequencyX.SetValue(25.0);
  checkerboardFrequencyY.Set(this, "checkerboardFrequencyY");
  checkerboardFrequencyY.Register("step=5.0 min=1.0 max=1000.0");
  checkerboardFrequencyY.SetValue(25.0);
  
  EnumPair ep[] = {{Supersampling::SUPERSAMPLING_NONE, "none"}, {Supersampling::SUPERSAMPLING_REGULAR, "regular"},
    {Supersampling::SUPERSAMPLING_QUINCUNX, "QUINCUNX"}, {Supersampling::SUPERSAMPLING_ROTATED, "rotated"},
    {Supersampling::SUPERSAMPLING_RANDOM, "random"}, {Supersampling::SUPERSAMPLING_STRATIFIED, "stratified"}};
  supersamplingType.Set(this, "sampling_type", ep, 6);
  supersamplingType.Register();
  supersamplingType = 0;
  
  sqrtSamples.Set(this, "sqrt(samples)");
  sqrtSamples.Register("step=1 min=1 max=4");
  sqrtSamples.SetValue(2);
}

bool Supersampling::Activate(void) {

  initiateGuiList();
  
  GenerateGround();
   // Initialize camera position: z = 3.0
  cameraPos = glm::vec4(0.0f, 0.5f, 6.0f, 1.0f);
  cameraRotX = cameraRotY = 0.0f;
  rotXMatrix = rotYMatrix = glm::mat4(1.0f);

  glEnable(GL_DEPTH_TEST);

  return true;
}

bool Supersampling::Deactivate(void) {

  glBindBuffer(GL_ARRAY_BUFFER,0);
  glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,0);
  return true;
}

bool Supersampling::Init(void) {
  if (gl3wInit()) {
    printf("Cannot initialize gl3w! No function pointers!\n");
    return false;
  }
  if (!gl3wIsSupported(3, 2)) {
    std::cerr << "OpenGL 3.2 not supported" << std::endl;
    return false;
  }
  return true;
}

bool Supersampling::Keyboard(unsigned char key, int x, int y) 
{
  switch(key) {
  case 'w': {
    cameraPos += rotYMatrix*glm::vec4(0.0f, 0.0f, -0.05f, 0.0f);
    return true;
  } 
  case 's': {
    cameraPos += rotYMatrix*glm::vec4(0.0f, 0.0f, 0.05f, 0.0f);
    return true;
  } 
  case 'a': {
    cameraPos += rotYMatrix*glm::vec4(-0.05f, 0.0f, 0.0f, 0.0f);
    return true;
  } 
  case 'd': {
    cameraPos += rotYMatrix*glm::vec4(0.05f, 0.0f, 0.0f, 0.0f);
    return true;
  } 
  }
  return false;
}

bool Supersampling::Mouse(int button, int state, int x, int y) {

  PostRedisplay();
  return false;
}

bool Supersampling::Motion(int x, int y) {

  if (IsLeftButtonPressed()) {

    int x_prev, y_prev;
    GetLastMousePos(x_prev, y_prev);
    int dx = x - x_prev;
    int dy = y - y_prev;

    cameraRotX += float(dy)*0.1f*M_PI/180.0f;
    cameraRotY += float(-dx)*0.1f*M_PI/180.0f;
  }

  PostRedisplay();
  return false;
}

void Supersampling::AssembleTransformMatrices()
{
  viewMX = glm::mat4(1.0f);
  const float initMatrix[16] = {1,0,0,-0,  0,1,0,0,  0,0,1,0,  0,-0.5,-3,1};
  viewMX = glm::make_mat4(initMatrix);
  
  // Aufgabe 6.2a) ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  // TODO:
  // Erstellen Sie die View-Matrix aus den Variablen cameraRotX, cameraRotY 
  // und cameraPos. Hierzu sollten Sie die Rotations-Matrizen rot{YX}Maxtrix
  // verwenden. Beachten Sie die Reihenfolge der Multiplikation! 
  // Hinweis: OpenGL ist column-major, d.h. die Translation steht vor dem 
  // Hochladen auf die GPU in den Elementen mit den Indices 12,13,14.
  // TODO:.
  // Use the variables cameraRotX, cameraRotY, and cameraPos to create the 
  // view matrix. Here, use the rotation matrices rot{YX}Matrix in correct 
  // order. Note that OpenGL arrays are ordered column major wise so
  // translation entries are stored at indices 12, 13, 14.
  
  //~Aufgabe 6.2a) ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  // Set perspective projection
  int width, height;
  this->GetWindowSize(width,height);
  // arguments:
  //   fov    The angle of the field of view.
  //   aspect The aspect ratio of the field of view.
  //   znear  The near clipping plane.
  //   zfar   The far clipping plane.
  projMX = glm::perspective(45.0f, width/(float)height, 0.01f,100.0f);
}

void Supersampling::Transform(GLuint program)
{
  // Load transformation matrices to shader uniforms
  glUniformMatrix4fv(glGetUniformLocation(program, "proj_matrix"),
		     1,GL_FALSE,glm::value_ptr(projMX));
  glUniformMatrix4fv(glGetUniformLocation(program, "view_matrix"),
		     1,GL_FALSE,glm::value_ptr(viewMX));
  glUniformMatrix4fv(glGetUniformLocation(program, "model_matrix"),
		     1,GL_FALSE,glm::value_ptr(modelMX));
  totalTransformInverse = glm::inverse(projMX * viewMX * modelMX);
  glUniformMatrix4fv(glGetUniformLocation(program, "totalTransformInverse"),
		     1,GL_FALSE,glm::value_ptr(totalTransformInverse));
  // glUniformMatrix4fv(GLint location, GLsizei count, GLboolean transpose, const GLfloat *value)
}

void Supersampling::Subsamples(GLuint program)
{
  /// BEGIN Load gui parameters to shader program.
  glm::vec2 checkerboardFrequency = glm::vec2(checkerboardFrequencyX.GetValue(), checkerboardFrequencyY.GetValue());
  glUniform2fv(glGetUniformLocation(program, "checkerboardFrequency"), 1, glm::value_ptr(checkerboardFrequency));
  glUniform1f(glGetUniformLocation(program, "groundXMin"), -5.0);
  glUniform1f(glGetUniformLocation(program, "groundXMax"),  5.0);
  glUniform1f(glGetUniformLocation(program, "groundYMin"), -5.0);
  glUniform1f(glGetUniformLocation(program, "groundYMax"),  5.0);
  
  glUniform1i(glGetUniformLocation(program, "supersamplingType"), supersamplingType);
  
  glUniform4fv(glGetUniformLocation(program, "cameraPos"), 1, glm::value_ptr(cameraPos));
  /// Image resolution in pixel
  int width, height;
  this->GetWindowSize(width, height);
  /// relative pixel size
  relativePixelSize[0] = 2.0 / static_cast<float>(width);
  relativePixelSize[1] = 2.0 / static_cast<float>(height);
  /// void glUniform4fv(GLint location, GLsizei count, const GLfloat *value);
  glUniform2fv(glGetUniformLocation(program, "relativePixelSize"), 1, glm::value_ptr(relativePixelSize));
  /// END Load gui parameters to shader program.
  
  /// Define deterministic subsample positions
  if(supersamplingType == Supersampling::SUPERSAMPLING_NONE) {
    
    const int sampleCount = 1;
    glUniform1i(glGetUniformLocation(program, "sampleCount"), sampleCount);
    float subsampleCoordinateArray[2] = { 0.0, 0.0 };
    glUniform2fv(glGetUniformLocation(program, "subsampleCoordinateArray"), 1, subsampleCoordinateArray);
    
  } else if (supersamplingType == Supersampling::SUPERSAMPLING_REGULAR) {
    /// BEGIN TODO Task d)
    /// Implement regular sampling by providing the relative sampling positions \in [-1, 1]^2, 
    /// fill subsampleCoordinateArray and send it with the sample count to the shader program.
    /// See the if-branch above to get an idea how to do this.

		const int sampleCount = sqrtSamples * sqrtSamples;
		glUniform1i(glGetUniformLocation(program, "sampleCount"), sampleCount);
		float subsampleCoordinateArray[sampleCount * 2];
		int i = 0;
		for (int y = 0; y < sqrtSamples; y++) {
			for (int x = 0; x < sqrtSamples; x++) {
				subsampleCoordinateArray[i++] = -1 + 1 / sqrtSamples + x * 2 / sqrtSamples;
				subsampleCoordinateArray[i++] = -1 + 1 / sqrtSamples + y * 2 / sqrtSamples;
			}
		}
		glUniform2fv(glGetUniformLocation(program, "subsampleCoordinateArray"), sampleCount, subsampleCoordinateArray);
		
    /// END   Task d)
  } else if (supersamplingType == Supersampling::SUPERSAMPLING_QUINCUNX) {
    /// BEGIN TODO Task e)
    
		const int sampleCount = sqrtSamples * sqrtSamples + (sqrtSamples + 1) * (sqrtSamples + 1);
		glUniform1i(glGetUniformLocation(program, "sampleCount"), sampleCount);
		float subsampleCoordinateArray[sampleCount * 2];
		int i = 0;
		for (int y = 0; y <= sqrtSamples; y++) {
			for (int x = 0; x <= sqrtSamples; x++) {
				subsampleCoordinateArray[i++] = x * 2 / sqrtSamples;
				subsampleCoordinateArray[i++] = y * 2 / sqrtSamples;

				if (x <= sqrtSamples && y <= sqrtSamples) {
					subsampleCoordinateArray[i++] = -1 + 1 / sqrtSamples + x * 2 / sqrtSamples;
					subsampleCoordinateArray[i++] = -1 + 1 / sqrtSamples + y * 2 / sqrtSamples;
				}
			}
		}

    /// END   Task e)
  } else if (supersamplingType == Supersampling::SUPERSAMPLING_ROTATED) {
    /// BEGIN TODO Task f)

		float angle = 26.6 * glm::pi<float>() * 2 / 360.0;
		float scale = sqrt(5) * .5;
    
		const int sampleCount = sqrtSamples * sqrtSamples;
		glUniform1i(glGetUniformLocation(program, "sampleCount"), sampleCount);
		float subsampleCoordinateArray[sampleCount * 2];
		int i = 0;
		for (int y = 0; y < sqrtSamples; y++) {
			for (int x = 0; x < sqrtSamples; x++) {
				float pos_x = -1 + 1 / sqrtSamples + x * 2 / sqrtSamples;
				float pos_y = -1 + 1 / sqrtSamples + y * 2 / sqrtSamples;
				subsampleCoordinateArray[i++] = (x * cos(angle) - y * sin(angle)) * scale;
				subsampleCoordinateArray[i++] = (x * sin(angle) - y * cos(angle)) * scale;
			}
		}
		glUniform2fv(glGetUniformLocation(program, "subsampleCoordinateArray"), sampleCount, subsampleCoordinateArray);

    /// END Task f)
  } else {
    /// BEGIN TODO Task g), h)

		const int sampleCount = sqrtSamples * sqrtSamples;
		glUniform1i(glGetUniformLocation(program, "sampleCount"), sampleCount);
		float subsampleCoordinateArray[sampleCount * 2];
		int i = 0;
		for (int y = 0; y < sqrtSamples; y++) {
			for (int x = 0; x < sqrtSamples; x++) {
				subsampleCoordinateArray[i++] = -1 + 1 / sqrtSamples + x * 2 / sqrtSamples;
				subsampleCoordinateArray[i++] = -1 + 1 / sqrtSamples + y * 2 / sqrtSamples;
			}
		}
		glUniform2fv(glGetUniformLocation(program, "subsampleCoordinateArray"), sampleCount, subsampleCoordinateArray);

    /// END   Task g), h)
  }
}

bool Supersampling::Render(void) {

  // set color used to clear the window
  glClearColor(0.0f, 0.5f, 1.0f, 1.0f);
  // clear color buffer and depth buffer
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  // Assemble the model, view and projection matrices
  AssembleTransformMatrices();

  glUseProgram(shaderProgram_ground);

  // Build transform matrices 
  Transform(shaderProgram_ground);
  
  // Transfer subsamples
  Subsamples(shaderProgram_ground);

  // Bind vertex array with tree mesh
  glBindVertexArray(va_ground);
  glDrawElements(GL_TRIANGLES, numIndices_ground, GL_UNSIGNED_INT, NULL);
  glBindVertexArray(0);

  glUseProgram(0);


  return false;
}

