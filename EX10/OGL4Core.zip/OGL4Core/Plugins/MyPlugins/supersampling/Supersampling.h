#include "RenderPlugin.h"
#include "glm.hpp"

// This class is exported from the Supersampling.dll
class OGL4COREPLUGIN_API Supersampling : public RenderPlugin {
 public:
  Supersampling(COGL4CoreAPI *Api);
  ~Supersampling(void);

  virtual void initiateGuiList();
  virtual bool Activate(void);
  virtual bool Deactivate(void);
  virtual bool Init(void);
  virtual bool Render(void);

  virtual bool Keyboard(unsigned char key, int x, int y);
  virtual bool Mouse(int button, int state, int x, int y);
  virtual bool Motion(int x, int y);
  
  static const int SUPERSAMPLING_NONE = 0;
  static const int SUPERSAMPLING_REGULAR = 1;
  static const int SUPERSAMPLING_QUINCUNX = 2;
  static const int SUPERSAMPLING_ROTATED = 3;
  static const int SUPERSAMPLING_RANDOM = 4;
  static const int SUPERSAMPLING_STRATIFIED = 5;

 private:

  GLuint CreateShaderProgram(const char *vertShaderFileName,
			     const char *fragShaderFileName);
  void Transform(GLuint program);
  void Subsamples(GLuint program);
  void AssembleTransformMatrices();
  
  void GenerateGround();

  glm::mat4 modelMX;
  glm::mat4 viewMX;
  glm::mat4 projMX;
  glm::mat4 totalTransformInverse;
  glm::vec4 cameraPos;
  float cameraRotX;
  float cameraRotY;
  glm::mat4 rotYMatrix;
  glm::mat4 rotXMatrix;
  glm::vec2 relativePixelSize;

  GLuint va_ground;  // vertex array
  GLuint vbo_ground; // vertex buffer
  GLuint ibo_ground; // index buffer
  GLuint cbo_ground; // color buffer

  unsigned int numVerts_ground;
  unsigned int numIndices_ground;

  // shader program 
  GLuint shaderProgram_ground;
  
  APIVar<Supersampling, FloatVarPolicy>  checkerboardFrequencyX;
  APIVar<Supersampling, FloatVarPolicy>  checkerboardFrequencyY;
  EnumVar<Supersampling> supersamplingType;
  APIVar<Supersampling, IntVarPolicy>  sqrtSamples;
};

extern "C" OGL4COREPLUGIN_API RenderPlugin* OGL4COREPLUGIN_CALL CreateInstance(COGL4CoreAPI *Api) {
  return new Supersampling(Api);
}
