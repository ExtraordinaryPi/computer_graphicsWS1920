/*
 * IoHelpers.h
 *
 * Copyright (C) 2011 by Universitaet Stuttgart (VIS/US).
 * Alle Rechte vorbehalten.
 */

#ifndef __CG_IOHELPERS__
#define __CG_IOHELPERS__

#include "GL3/gl3w.h"

char *loadRAW(const char *filename, GLuint &width, GLuint &height, GLuint &channels);

float *loadHeightField(const char *filename, GLuint &width, GLuint &height, GLuint &channels);

#endif /* __CG_IOHELPERS__ */
