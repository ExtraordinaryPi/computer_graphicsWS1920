/*
 * GLHelpers.h
 *
 * Copyright (C) 2011 by Universitaet Stuttgart (VIS/US).
 * Alle Rechte vorbehalten.
 */

#ifndef __CG_GLHELPERS__
#define __CG_GLHELPERS__

#include "GL3/gl3w.h"

#define GLCE(x) glGetError(); (x); checkError(__FILE__, __LINE__);

GLenum checkError(char *file, int line);

bool IsValidFramebufferObject(GLint fbo);

#endif /* __CG_GLHELPERS__ */