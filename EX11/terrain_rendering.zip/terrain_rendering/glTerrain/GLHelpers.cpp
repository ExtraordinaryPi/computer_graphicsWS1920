#include "GLHelpers.h"
#include <iostream>
#include <stdio.h>

GLenum checkError(char *file, int line) {
    GLenum __theError;
    __theError = glGetError();
    if (__theError != GL_NO_ERROR) {
        switch(__theError) {
            case GL_INVALID_ENUM:
                printf("GL_INVALID_ENUM at %s:%u\n", file, line);
                break;
            case GL_INVALID_VALUE:
                printf("GL_INVALID_VALUE at %s:%u\n", file, line);
                break;
            case GL_INVALID_OPERATION:
                printf("GL_INVALID_OPERATION at %s:%u\n", file, line);
                break;
            case GL_OUT_OF_MEMORY:
                printf("GL_OUT_OF_MEMORY at %s:%u\n", file, line);
                break;
        }
    }
    return __theError;
}

bool IsValidFramebufferObject(GLint fbo) {

    GLint fboSaved(0);
    glGetIntegerv( GL_FRAMEBUFFER_BINDING, &fboSaved);
    glBindFramebuffer(GL_FRAMEBUFFER, fbo);

    bool isOK = false;

    GLenum status;                                            
    status = glCheckFramebufferStatus(GL_FRAMEBUFFER);
    switch(status) {                                          
    case GL_FRAMEBUFFER_COMPLETE: // Everything's OK
        isOK = true;
        break;
    case GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT:
        std::cout << "glift::CheckFramebufferStatus() ERROR:\n\t"
            << "GL_FRAMEBUFFER_INCOMPLETE_ATTACHMENT\n";
        isOK = false;
        break;
    case GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT:
        std::cout << "glift::CheckFramebufferStatus() ERROR:\n\t"
            << "GL_FRAMEBUFFER_INCOMPLETE_MISSING_ATTACHMENT\n";
        isOK = false;
        break;
    case GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER:
        std::cout << "glift::CheckFramebufferStatus() ERROR:\n\t"
            << "GL_FRAMEBUFFER_INCOMPLETE_DRAW_BUFFER\n";
        isOK = false;
        break;
    case GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER:
        std::cout << "glift::CheckFramebufferStatus() ERROR:\n\t"
            << "GL_FRAMEBUFFER_INCOMPLETE_READ_BUFFER\n";
        isOK = false;
        break;
    case GL_FRAMEBUFFER_UNSUPPORTED:
        std::cout << "glift::CheckFramebufferStatus() ERROR:\n\t"
            << "GL_FRAMEBUFFER_UNSUPPORTED\n";
        isOK = false;
        break;
    default:
        std::cout << "glift::CheckFramebufferStatus() ERROR:\n\t"
            << "Unknown ERROR\n";
        isOK = false;
    }

    glBindFramebuffer(GL_FRAMEBUFFER, fboSaved);

    return isOK;
}