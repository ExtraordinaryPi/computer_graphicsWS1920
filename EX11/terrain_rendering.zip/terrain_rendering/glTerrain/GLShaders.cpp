#ifdef _WIN32
#define _CRT_SECURE_NO_WARNINGS 1
#endif /* _WIN32 */

#include "GLShaders.h"
#include <cstring>
#include <stdio.h>

bool printShaderInfoLog(GLuint shader) {
    int infoLogLen = 0;
    int charsWritten = 0;
    GLchar *infoLog;

    int compileStatus(0);

    glGetShaderiv(shader, GL_COMPILE_STATUS, &compileStatus);
    glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &infoLogLen);

    if (infoLogLen > 1)	{
        infoLog = new GLchar[infoLogLen];
        // error check for fail to allocate memory omitted
        glGetShaderInfoLog(shader, infoLogLen, &charsWritten, infoLog);
        printf("InfoLog : %s\n", infoLog);
        delete [] infoLog;
    }
    return (compileStatus == GL_TRUE);
}

bool printProgramInfoLog(GLuint program) {
    int infoLogLen = 0;
    int charsWritten = 0;
    GLchar *infoLog;

    int linkStatus(0);

    glGetProgramiv(program, GL_INFO_LOG_LENGTH, &infoLogLen);
    glGetProgramiv(program, GL_LINK_STATUS, &linkStatus);

    if (infoLogLen > 1)	{
        infoLog = new GLchar[infoLogLen];
        // error check for fail to allocate memory omitted
        glGetProgramInfoLog(program, infoLogLen, &charsWritten, infoLog);
        printf("ProgramInfoLog : %s\n", infoLog);
        delete [] infoLog;
    }
    return (linkStatus == GL_TRUE);
}

GLuint loadFile(const char *filename, char ***lines, int **lineLens) {
    FILE *file = fopen (filename, "r" );
    const int bufSize = 1024;

    if (file != NULL) {
        int numLines = 0;
        char line [bufSize];
        while (fgets(line, bufSize, file) != NULL ) {
            numLines++;
        }
        *lines = new char*[numLines];
        *lineLens = new int[numLines];

        int count = 0;
        fseek(file, 0, SEEK_SET);
        while (fgets(line, bufSize, file) != NULL ) {
            (*lineLens)[count] = strlen(line);
            (*lines)[count] = new char[(*lineLens)[count] + 1];
            strcpy((*lines)[count], line);
            count++;
        }
        fclose (file);
        return numLines;
    }
    return 0;
}

GLuint loadShader(GLenum type, const char *fileName) {
    char **lines = NULL;
    int *lineLens = NULL;
    GLuint numLines;

    GLuint shader = glCreateShader(type);
    if (shader > 0) {
        numLines = loadFile(fileName, &lines, &lineLens);
        if (numLines > 0) {
            GLCE(glShaderSource(shader, numLines, const_cast<const char**>(lines), lineLens));
            GLCE(glCompileShader(shader));
        } else {
            glDeleteShader(shader);
            shader = 0;
        }
    }
    return shader;
}

void detachAndDelete(GLuint program) {
    if (!glIsProgram(program)) {
        return;
    }
    const GLsizei numShaders = 1024;
    GLsizei numReturned;
    GLuint shaders[numShaders];
    GLCE(glUseProgram(0));
    GLCE(glGetAttachedShaders(program, numShaders, &numReturned, shaders));
    for (GLsizei i = 0; i < numReturned; i++) {
        GLCE(glDetachShader(program, shaders[i]));
        GLCE(glDeleteShader(shaders[i]));
    }
    glDeleteProgram(program);
}

GLuint loadShaders(const char *vShaderPath, const char *fShaderPath, const char *gShaderPath,
    const char *tcShaderPath, const char *teShaderPath, const char *commonShaderPath) {
    char **lines = NULL;
    int *lineLens = NULL;
    GLuint vs, fs, gs, tc, te, cs, cs2, cs3, cs4, cs5;
    GLuint prog;

    GLCE(prog = glCreateProgram());

    vs = loadShader(GL_VERTEX_SHADER, vShaderPath);
    fs = loadShader(GL_FRAGMENT_SHADER, fShaderPath);
    if (commonShaderPath != NULL) {
        cs = loadShader(GL_VERTEX_SHADER, commonShaderPath);
        cs5 = loadShader(GL_FRAGMENT_SHADER, commonShaderPath);
    }

    gs = 0;
    if (gShaderPath != NULL) {
        gs = loadShader(GL_GEOMETRY_SHADER, gShaderPath);
        cs4 = loadShader(GL_GEOMETRY_SHADER, commonShaderPath);
    }

    tc = te = 0;
    if (tcShaderPath != NULL) {
        tc = loadShader(GL_TESS_CONTROL_SHADER, tcShaderPath);
        cs2 = loadShader(GL_TESS_CONTROL_SHADER, commonShaderPath);
    }
    
    if (teShaderPath != NULL) {
        te = loadShader(GL_TESS_EVALUATION_SHADER, teShaderPath);
        cs3 = loadShader(GL_TESS_EVALUATION_SHADER, commonShaderPath);
    }

    GLCE(glAttachShader(prog, vs));
    GLCE(glAttachShader(prog, fs));
    if (commonShaderPath != NULL) {
        GLCE(glAttachShader(prog, cs));
        GLCE(glAttachShader(prog, cs5));
    }
    if (gs > 0) {
        GLCE(glAttachShader(prog, gs));
        GLCE(glAttachShader(prog, cs4));
    }
    if (tc > 0) {
        GLCE(glAttachShader(prog, tc));
        GLCE(glAttachShader(prog, cs2));
    }
    if (te > 0 ) {
        GLCE(glAttachShader(prog, te));
        GLCE(glAttachShader(prog, cs3));
    }

    return prog;
}