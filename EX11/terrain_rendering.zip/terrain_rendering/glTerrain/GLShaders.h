/**
 * GLShader.h
 *
 * Copyright (C) 2011 by Universitaet Stuttgart (VIS/US).
 * Alle Rechte vorbehalten.
 */

#ifndef __CG_GLSHADERS__
#define __CG_GLSHADERS__

#include "GLHelpers.h"

#ifndef UNIX
//#pragma warning (disable:4996)
#endif

bool printShaderInfoLog(GLuint shader);

bool printProgramInfoLog(GLuint program);

GLuint loadFile(const char *filename, char ***lines, int **lineLens);

/**
 * Creates a type of shader and loads the contents of a file
 * into it.
 *
 * @returns the shader handle
 */
GLuint loadShader(GLenum type, const char *fileName);

/**
 * Detaches all shaders from program and deletes them. Finally deletes program itself.
 * side effect: glUseProgram(0);
 */
void detachAndDelete(GLuint program);

/**
 * Loads one shader per stage and attaches the common shader to all of them.
 * Shaders are compiled, but NOT linked, so Attributes can still be bound.
 */
GLuint loadShaders(const char *vShaderPath, const char *fShaderPath, const char *gShaderPath,
    const char *tcShaderPath, const char *teShaderPath, const char *commonShaderPath);

#endif /* __CG_GLSHADERS__ */
