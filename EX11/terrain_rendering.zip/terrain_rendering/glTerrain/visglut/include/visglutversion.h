/*
 * visglutversion.h
 *
 * Copyright (C) 2009 by VISUS (Universitaet Stuttgart)
 * Alle Rechte vorbehalten.
 */

#ifndef VISGLUTVERSION_H_INCLUDED
#define VISGLUTVERSION_H_INCLUDED
#if (_MSC_VER > 1000)
#pragma once
#endif /* (_MSC_VER > 1000) */

/*
 * DO NOT EDIT
 * THIS FILE IS GENERATED FROM visglutversion.template.h
 */

#define VISGLUT_REVISION 60
#define VISGLUT_DIRTY    0

#endif /* VISGLUTVERSION_H_INCLUDED */
