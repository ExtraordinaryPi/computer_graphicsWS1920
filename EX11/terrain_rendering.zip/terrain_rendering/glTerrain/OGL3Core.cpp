/*
 * OGL3Core.cpp
 *
 * Copyright (C) 2011 by Universitaet Stuttgart (VIS/US).
 * Alle Rechte vorbehalten.
 *
 * Open GL 4.0: tesselation shader
 *
 * Problems: lags during roation mode - issue with the idle function?
 */

#ifdef _WIN32
#include "stdafx.h"
#else
#include <cstring>
#endif

#include <cassert>
#include <iostream>
#include <limits>

#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "glm/gtc/type_ptr.hpp"

#include "gl3w/include/GL3/gl3w.h"
#include <stdio.h>
#define _USE_MATH_DEFINES
#include <math.h>
#include "trackball.h"
#include "GLHelpers.h"
#include "GLShaders.h"
#include "IoHelpers.h"
#include "Image.h"
#include "PerformanceCounter.h"

#ifndef _WIN32
#include <GL/freeglut.h>
#else /* _WIN32 */
#include "visglut.h"
#endif /* _WIN32 */

#pragma warning(disable : 4996)

// forward declarations
bool initTextures(void);

class TextureWeights
{
public:
	//
	// Texture weight function constructed from two linear ramps.
	//
	// A texture is not displayed at height values smaller than a
	// or larger than d (weight=0). Within height range [b,c] the textures
	// weight becomes 1 (visible). Linear blending inbetween [a,b] and [c,d]:
	//
	//  ^  weight
	//  |
	// 1.0
	//  |         /------\
    // 0.0  _____/|      |\___
	//  |       | |      | |
	//  |       a b      c d
	//  x------ height value h ----->
	//

	TextureWeights(float a, float b, float c, float d)
	{
		controlPoints[0] = a;
		controlPoints[1] = b;
		controlPoints[2] = c;
		controlPoints[3] = d;

		if (!((a <= b) && (b <= c) && (c <= d)))
		{
			std::cout << "Error: defect in TextureWeights control points!" << std::endl;
		}
	}

	float *DataPointer()
	{
		return &controlPoints[0];
	}

	float controlPoints[4];
};

// program state
class State
{

public:
	class OpenGLState
	{
	public:
		OpenGLState() : primitivesGeneratedQuery(0),
						terrainTexArray(0){};

		GLuint primitivesGeneratedQuery;
		GLuint terrainTexArray;
	};

	State() : displayFrameCounter(false),
			  displayTerrain(true),
			  displayTrees(false),
			  displayWireframe(false),
			  enableMultiTexturing(false),
			  frameCounter(0),
			  lastTime(PerformanceCounter::Query()),
			  lodEnabled(true),
			  orbitFactor(0.5f),
			  terrainHeightScalingFactor(2.0),
			  terrainLevelOfDetailPixelThresh(8),
			  terrainOrigin(glm::vec2(-10.0, -10.0)),
			  terrainPatchGridResolution(8),
			  terrainPatchSubDivisions(1),
			  terrainSize(glm::vec2(20.0, 20.0)),
			  terrainTextureNumRepeat(30),
			  terrainTriangleCountEnabled(false),
			  showTesselation(false),
			  showTexels(false),
			  showIsolines(false),
			  zoomFactor(0.025f),
			  sqrtNumInstances(256),
			  numInstances(sqrtNumInstances * sqrtNumInstances),
			  windowW(512), windowH(512)
	{
		//
		// TODO Exercise d) (optional):
		// Choose your own textures and weighting functions,
		// terrain texture image names, note the
		// textures need to be of the same size!!
		//
		terrainTextureImages.push_back("terrain/water.ppm");
		terrainTextureWeights.push_back(TextureWeights(-10.0f, 0.0f, 0.01f, 0.02f));
		terrainTextureImages.push_back("terrain/rock.ppm");
		terrainTextureWeights.push_back(TextureWeights(0.01f, 0.02f, 0.1f, 0.15f));
		terrainTextureImages.push_back("terrain/grass.ppm");
		terrainTextureWeights.push_back(TextureWeights(0.1f, 0.15f, 0.35f, 0.5f));
		terrainTextureImages.push_back("terrain/graydirt.ppm");
		terrainTextureWeights.push_back(TextureWeights(0.35f, 0.5f, 0.75f, 0.85f));
		terrainTextureImages.push_back("terrain/snow.ppm");
		terrainTextureWeights.push_back(TextureWeights(0.75f, 0.85f, 1.0f, 1.0f));
		assert(terrainTextureWeights.size() == terrainTextureImages.size());
	};

	bool displayFrameCounter;
	bool displayTerrain;
	bool displayTrees;
	bool displayWireframe;
	bool enableMultiTexturing;
	unsigned int frameCounter;
	UINT64 lastTime;
	bool lodEnabled;
	float orbitFactor;

	float terrainHeightScalingFactor;
	unsigned int terrainLevelOfDetailPixelThresh;
	std::vector<std::string> terrainTextureImages;
	std::vector<TextureWeights> terrainTextureWeights;
	glm::vec2 terrainOrigin;
	unsigned int terrainPatchGridResolution;
	unsigned int terrainPatchSubDivisions;
	glm::vec2 terrainSize;
	unsigned int terrainTextureNumRepeat;
	bool terrainTriangleCountEnabled;
	bool showTesselation;
	bool showTexels;
	bool showIsolines;

	float zoomFactor;

	unsigned int sqrtNumInstances;
	unsigned int numInstances;

	int windowW;
	int windowH;

	OpenGLState gl;
};

State state;

//
// the geometry data arrays
//

// terrain base quad
GLfloat quadVerts[] = {
	0.f, 0.f, 0.f,
	1.0f, 0.f, 0.f,
	1.0f, 1.0f, 0.f,
	0.f, 1.0f, 0.f};

// terrain base quad texture coordinates
GLfloat quadTexCoords[] = {
	0.f,
	0.f,
	1.f,
	0.f,
	0.f,
	1.f,
	1.f,
	1.f,
};

// the two quads for the tree
GLfloat treeVertices[] = {
	-0.5f, 0.f, 0.f,
	0.5f, 0.f, 0.f,
	-0.5f, 1.f, 0.f,
	0.5f, 1.f, 0.f,
	0.f, 0.f, -0.5f,
	0.f, 0.f, 0.5f,
	0.f, 1.f, -0.5f,
	0.f, 1.f, 0.5f};

// tree texture coordinates
GLfloat treeTexCoords[] = {
	0.f, 0.f,
	1.f, 0.f,
	0.f, 1.f,
	1.f, 1.f,
	0.f, 0.f,
	1.f, 0.f,
	0.f, 1.f,
	1.f, 1.f};

glm::mat4 projMX, modelMX, viewMX;
GLuint flatness, vbo4, treeVA, treeBO;
int crossVertices, thingVertices, planeVertices;
GLuint heightTex, terrainTex, treeTex, instanceTex;
GLuint terrainProg, treeProg;
int spinning = 0, moving = 0;
int beginx, beginy;
float curquat[4];
float lastquat[4];
float curCamquat[4];
float lastCamquat[4];
int newModel = 1;
int scaling;
float dolly = -10.f;
GLboolean orbitCamera = GL_FALSE;

/**
 * Load gl shaders
 */
void loadShaders()
{

	std::cout << "Info: loading shaders!" << std::endl;

	std::cout << "Info: loading terrain shader program" << std::endl;

	detachAndDelete(terrainProg);
	/*
    terrainProg = loadShaders("shaders/terrain-vertex.glsl", 
                              "shaders/terrain-fragment.glsl", 
                              "shaders/terrain-geo.glsl", 
                              "shaders/terrain-tcontrol.glsl", 
                              "shaders/terrain-teval.glsl",
                              "shaders/terrain-common.glsl");
                              */
	terrainProg = loadShaders("shaders/terrain-vertex.glsl",
							  "shaders/terrain-fragment.glsl",
							  NULL,
							  "shaders/terrain-tcontrol.glsl",
							  "shaders/terrain-teval.glsl",
							  "shaders/terrain-common.glsl");
	GLCE(glBindAttribLocation(terrainProg, 0, "in_position"));
	GLCE(glBindFragDataLocation(terrainProg, 0, "out_frag_color"));
	GLCE(glLinkProgram(terrainProg));
	printProgramInfoLog(terrainProg);
	GLCE(glUseProgram(terrainProg));

	std::cout << "Info: loading tree shader program" << std::endl;

	detachAndDelete(treeProg);
	treeProg = loadShaders("shaders/trees-vertex.glsl",
						   "shaders/trees-fragment.glsl",
						   NULL, NULL, NULL,
						   "shaders/terrain-common.glsl");

	GLCE(glBindAttribLocation(treeProg, 0, "in_vertex"));
	GLCE(glBindAttribLocation(treeProg, 1, "in_textureCoordinate"));
	GLCE(glBindFragDataLocation(treeProg, 0, "out_frag_color"));
	GLCE(glLinkProgram(treeProg));
	printProgramInfoLog(treeProg);
	GLCE(glUseProgram(treeProg));
}

/**
 * Initialize OpenGL states.
 */
void init(void)
{

	if (gl3wInit())
	{
		fprintf(stderr, "failed to initialize gl3w!\n");
		exit(4);
	}

	const GLubyte *ven = glGetString(GL_VENDOR);
	ven = glGetString(GL_VERSION);
	GLint val;
	glGetIntegerv(GL_MAX_VERTEX_STREAMS, &val);

	glClearColor(1.0, 1.0, 1.0, 1.0);
	glClearDepth(1.0); // min. Tiefe 0.0, max. Tiefe 1.0
	glEnable(GL_DEPTH_TEST);

	loadShaders();
	if (!initTextures())
	{
		std::cout << "Error: initTextures() failed!" << std::endl;
		exit(4);
	}

	if (!state.gl.primitivesGeneratedQuery)
	{
		glGenQueries(1, &state.gl.primitivesGeneratedQuery);
	}
}

/**
 * Initialize gl textures.
 */
bool initTextures(void)
{

	glGenTextures(1, &heightTex);
	glGenTextures(1, &terrainTex);
	glGenTextures(1, &treeTex);

	std::cout << "Info: init textures" << std::endl;

	GLuint width, height, channels;

	// 2D texture: height field
	std::cout << "Info: Loading (terrain/T1_height.r32)" << std::endl;
	float *bufHeight = loadHeightField("terrain/T1_height.r32", width, height, channels);
	if (!bufHeight)
	{
		std::cout << "Error: loading terrain/T1_height.r32 failed!" << std::endl;
		exit(EXIT_FAILURE);
	}

	// determine min and max height of heightfield
	float min = std::numeric_limits<float>::max();
	float max = std::numeric_limits<float>::min();

	for (unsigned int i = 0; i < width * height; i++)
	{
		if (bufHeight[i] < min)
		{
			min = bufHeight[i];
		}
		else if (bufHeight[i] > max)
		{
			max = bufHeight[i];
		}
	}

	std::cout << "Info (terrain/T1_height.r32): "
			  << width << "x" << height
			  << ", size in MB = " << (width * height * sizeof(float) / 1024.0 / 1024.0)
			  << ", height min = " << min
			  << ", height max = " << max
			  << std::endl;

	GLCE(glActiveTexture(GL_TEXTURE0));
	GLCE(glBindTexture(GL_TEXTURE_2D, heightTex));
	//buf = loadHeightField("terrain/10ksq.r32", width, height, channels);
	//ASSERT(channels == 1);
	GLCE(glTexImage2D(GL_TEXTURE_2D, 0, GL_R32F, width, height, 0, GL_RED, GL_FLOAT, bufHeight));
	GLCE(glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR));
	GLCE(glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR));
	GLCE(glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE));
	GLCE(glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE));

	delete[] bufHeight;

	// 2d texture: terrain texture
	std::cout << "Info: Loading (terrain/t1_tex.raw)" << std::endl;
	char *bufTex = loadRAW("terrain/t1_tex.raw", width, height, channels);
	if (!bufTex)
	{
		std::cout << "Error: loading terrain/t1_tex.raw failed!" << std::endl;
		exit(EXIT_FAILURE);
	}
	std::cout << "Info (terrain/t1_tex.raw): " << width << "x" << height << std::endl;

	GLCE(glActiveTexture(GL_TEXTURE1));
	GLCE(glBindTexture(GL_TEXTURE_2D, terrainTex));
	GLCE(glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, bufTex));
	GLCE(glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST));
	delete[] bufTex;

	// 2D texture: tree
	std::cout << "Info: Loading image (tree.ppm)" << std::endl;
	ImageRGBA tree;
	if (!tree.LoadFromPPM("tree.ppm"))
	{
		printf("Error: failed to load image data (tree.ppm)!\n");
	}
	else
	{
		GLCE(glActiveTexture(GL_TEXTURE2));
		GLCE(glBindTexture(GL_TEXTURE_2D, treeTex));
		GLCE(glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, tree.GetWidth(), tree.GetHeight(), 0, GL_RGBA, GL_UNSIGNED_BYTE, tree.GetDataPointer()));
		//GLCE(glGenerateMipmap(GL_TEXTURE_2D));
		//GLCE(glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR));
		GLCE(glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR));
		GLCE(glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR));
	}

	// 2D texture: for tree instancing
	std::cout << "Info: creating instancing texture" << std::endl;
	std::vector<float> positions(state.numInstances * 2);

	positions[0] = 0.0; // xpos
	positions[1] = 0.0; // zpos

	for (unsigned int i = 1; i < positions.size() / 2; i++)
	{
		positions[2 * i + 0] = (static_cast<float>(rand()) / RAND_MAX);
		positions[2 * i + 1] = (static_cast<float>(rand()) / RAND_MAX);
	}

	GLCE(glGenTextures(1, &instanceTex));
	GLCE(glBindTexture(GL_TEXTURE_2D, instanceTex));
	GLCE(glTexImage2D(GL_TEXTURE_2D, 0, GL_RG32F, state.sqrtNumInstances, state.sqrtNumInstances,
					  0, GL_RG, GL_FLOAT, &positions[0]));
	GLCE(glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST));
	GLCE(glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST));
	GLCE(glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT));

	// 2D texture array for terrain textures
	const unsigned int numTerrainTextures(state.terrainTextureImages.size());
	std::vector<ImageRGBA> terrainTextureImages(numTerrainTextures);

	std::cout << "Info: num terrain textures = " << numTerrainTextures << std::endl;

	bool failed = false;

	for (unsigned int i = 0; i < numTerrainTextures; i++)
	{
		const std::string fileName(state.terrainTextureImages[i]);
		std::cout << "Info: loading terrain image (" << fileName << ", ";
		if (!terrainTextureImages[i].LoadFromPPM(fileName))
		{
			std::cout << "Error: failed to load image data (" << fileName << ")!" << std::endl;
			failed = true;
			break;
		}

		std::cout << "image size = "
				  << terrainTextureImages[i].GetWidth()
				  << " x "
				  << terrainTextureImages[i].GetHeight()
				  << ")" << std::endl;

		if (i > 0 &&
			(terrainTextureImages[i].GetWidth() != terrainTextureImages[0].GetWidth() ||
			 terrainTextureImages[i].GetHeight() != terrainTextureImages[0].GetHeight()))
		{
			std::cout << "Error: same resolution for all terrain images required!" << std::endl;
			failed = true;
			break;
		}
	}

	if (failed)
	{
		return false;
	}

	std::cout << "Info: creating terrain texture array" << std::endl;

	if (!state.gl.terrainTexArray)
	{
		glGenTextures(1, &state.gl.terrainTexArray);
	}
	glBindTexture(GL_TEXTURE_2D_ARRAY, state.gl.terrainTexArray);

	glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D_ARRAY, GL_TEXTURE_WRAP_T, GL_REPEAT);

	GLCE(glTexImage3D(GL_TEXTURE_2D_ARRAY, 0, GL_RGBA8,
					  terrainTextureImages[0].GetWidth(),
					  terrainTextureImages[0].GetHeight(),
					  numTerrainTextures, 0, GL_RGBA, GL_UNSIGNED_BYTE, NULL));

	// HACK: sub imageapproach does not work
	for (unsigned int i = 0; i < numTerrainTextures; i++)
	{
		GLCE(glTexSubImage3D(GL_TEXTURE_2D_ARRAY, 0, 0, 0, i,
							 terrainTextureImages[i].GetWidth(),
							 terrainTextureImages[i].GetHeight(),
							 1, GL_RGBA, GL_UNSIGNED_BYTE,
							 terrainTextureImages[i].GetDataPointer()));
	}

	/*
    GLCE(glTexImage3D(GL_TEXTURE_2D_ARRAY, 0, GL_RGBA8, 
                      terrainTextureImages[0].GetWidth(), 
                      terrainTextureImages[0].GetHeight(), 
                      1, 0, GL_RGBA, GL_UNSIGNED_BYTE, terrainTextureImages[0].GetDataPointer()));
    */

	GLCE(glGenerateMipmap(GL_TEXTURE_2D_ARRAY));

	return true;
}

/**
 * Initialize gl geometry
 */
void initGeometry(void)
{

	std::cout << "Info: init geometry" << std::endl;

	//
	// terrain base quad
	//

	GLCE(glGenVertexArrays(1, &flatness));
	GLCE(glBindVertexArray(flatness));
	GLCE(glGenBuffers(1, &vbo4));
	GLCE(glBindBuffer(GL_ARRAY_BUFFER, vbo4));
	GLCE(glEnableVertexAttribArray(0));
	GLCE(glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * 3 * 4, quadVerts, GL_STATIC_DRAW));
	GLCE(glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, NULL));

	//
	// tree geometry
	//

	GLCE(glGenVertexArrays(1, &treeVA));
	GLCE(glBindVertexArray(treeVA));
	GLCE(glGenBuffers(1, &treeBO));
	GLCE(glBindBuffer(GL_ARRAY_BUFFER, treeBO));

	std::vector<GLfloat> data(5 * 8);

	for (unsigned int vIdx = 0; vIdx < 8; vIdx++)
	{
		data[5 * vIdx + 0] = treeVertices[3 * vIdx + 0];
		data[5 * vIdx + 1] = treeVertices[3 * vIdx + 1];
		data[5 * vIdx + 2] = treeVertices[3 * vIdx + 2];
		data[5 * vIdx + 3] = treeTexCoords[2 * vIdx + 0];
		data[5 * vIdx + 4] = treeTexCoords[2 * vIdx + 1];
	}

	GLCE(glBufferData(GL_ARRAY_BUFFER, sizeof(GLfloat) * 5 * 8, &data[0], GL_STATIC_DRAW));

	// attribute: vertices
	GLCE(glEnableVertexAttribArray(0));
	GLCE(glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 5, NULL));

	// attribute: texture coordinates
	GLCE(glEnableVertexAttribArray(1));
	GLCE(glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(GLfloat) * 5,
							   reinterpret_cast<const GLvoid *>(sizeof(GLfloat) * 3)));

	GLCE(glBindVertexArray(0));
}

/**
 * Cleanup
 */
void uninit(void)
{
	glDeleteBuffers(1, &vbo4);
	glDeleteBuffers(1, &treeBO);
	glDeleteVertexArrays(1, &flatness);
	glDeleteVertexArrays(1, &treeVA);
	glDeleteTextures(1, &heightTex);
	glDeleteTextures(1, &terrainTex);
	glDeleteTextures(1, &treeTex);
}

/**
 * callback when idling
 */
void idle(void)
{
	if (state.displayFrameCounter)
	{
		glutPostRedisplay();
	}
}

/**
 * callback for continuous motion
 */
void animate(void)
{
	if (orbitCamera)
	{
		add_quats(lastCamquat, curCamquat, curCamquat);
	}
	else
	{
		add_quats(lastquat, curquat, curquat);
	}
	newModel = 1;
	glutPostRedisplay();
}

/**
 * callback for mouse button interaction
 *
 * @param button    the button interacted with
 * @param state     GLUT_UP or GLUT_DOWN
 * @param x         mouse x at the moment of interaction
 * @param y         mouse y at the moment of interaction
 */
void mouse(int button, int state, int x, int y)
{

	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
	{
		glutIdleFunc(idle);
		moving = true;
		beginx = x;
		beginy = y;
		if (glutGetModifiers() & GLUT_ACTIVE_SHIFT)
		{
			scaling = 1;
		}
		else
		{
			scaling = 0;
		}
	}

	if (button == GLUT_LEFT_BUTTON && state == GLUT_UP)
	{
		moving = false;
	}
}

/**
 * callback for mouse motion
 *
 * @param x     mouse x
 * @param y     mouse y
 */
void motion(int x, int y)
{
	if (scaling)
	{
		//  scalefactor = state.zoomFactor * (1.0f + (((float) (beginy - y)) / state.windowH * 8.0f));
		dolly += (beginy - y);
		beginx = x;
		beginy = y;
		newModel = 1;
		glutPostRedisplay();
		return;
	}
	if (moving)
	{
		if (orbitCamera)
		{
			trackball(lastCamquat,
					  state.orbitFactor * (2.0f * beginx - state.windowW) / state.windowW,
					  state.orbitFactor * (state.windowH - 2.0f * beginy) / state.windowH,
					  state.orbitFactor * (2.0f * x - state.windowW) / state.windowW,
					  state.orbitFactor * (state.windowH - 2.0f * y) / state.windowH);
		}
		else
		{
			trackball(lastquat,
					  state.orbitFactor * (2.0f * beginx - state.windowW) / state.windowW,
					  state.orbitFactor * (state.windowH - 2.0f * beginy) / state.windowH,
					  state.orbitFactor * (2.0f * x - state.windowW) / state.windowW,
					  state.orbitFactor * (state.windowH - 2.0f * y) / state.windowH);
		}
		beginx = x;
		beginy = y;
		glutIdleFunc(animate);
	}
}

/**
 * callback for keyboard input
 *
 * @param key   the key pressed
 * @param x     mouse x at the moment of pressing
 * @param y     mouse y at the moment of pressing
 */
void keyboard(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 'a':
		state.lodEnabled = !state.lodEnabled;
		std::cout << "Info: state.lodEnabled = " << state.lodEnabled << std::endl;
		glutPostRedisplay();
		break;
	case 'b':
	{
		state.displayFrameCounter = !state.displayFrameCounter;
		const std::string stateStr((state.displayFrameCounter) ? "enabled" : "disabled");
		std::cout << "Info: benchmark " + stateStr << std::endl;
	}
	break;
	case 'c':
	{
		state.terrainTriangleCountEnabled = !state.terrainTriangleCountEnabled;
		const std::string stateStr((state.terrainTriangleCountEnabled) ? "enabled" : "disabled");
		std::cout << "Info: triangle count " + stateStr << std::endl;
	}
	break;
	case 'l':
	case 'L':
		loadShaders();
		glutPostRedisplay();
		break;
	case 'm':
		state.enableMultiTexturing = !state.enableMultiTexturing;
		std::cout << "Info: state.enableMultiTexturing = " << state.enableMultiTexturing << std::endl;
		glutPostRedisplay();
		break;
	case 'P':
		state.terrainPatchSubDivisions *= 2;
		printf("Info: state.terrainPatchSubDivisions = %u\n", state.terrainPatchSubDivisions);
		glutPostRedisplay();
		break;
	case 'p':
		state.terrainPatchSubDivisions /= 2;
		if (state.terrainPatchSubDivisions < 1)
			state.terrainPatchSubDivisions = 1;
		printf("Info: state.terrainPatchSubDivisions = %u\n", state.terrainPatchSubDivisions);
		glutPostRedisplay();
		break;
	case 'q':
	case 'Q':
		exit(EXIT_SUCCESS);
		break;
	case 's':
		state.terrainHeightScalingFactor /= 1.1f;
		if (state.terrainHeightScalingFactor <= 0.1f)
		{
			state.terrainHeightScalingFactor = 0.1f;
		}
		glutPostRedisplay();
		break;
	case 'S':
		state.terrainHeightScalingFactor *= 1.1f;
		glutPostRedisplay();
		break;
	case 't':
		state.displayTrees = !state.displayTrees;
		std::cout << "Info: state.displayTrees = " << state.displayTrees << std::endl;
		glutPostRedisplay();
		break;
	case 'T':
		state.displayTerrain = !state.displayTerrain;
		std::cout << "Info: state.displayTerrain = " << state.displayTerrain << std::endl;
		glutPostRedisplay();
		break;
	case 'w':
		state.displayWireframe = !state.displayWireframe;
		std::cout << "Info: state.displayWireframe = " << state.displayWireframe << std::endl;
		glutPostRedisplay();
		break;
	case 'x':
		state.showTexels = !state.showTexels;
		printf("Info: %sshowing texels\n", state.showTexels ? "" : "not ");
		glutPostRedisplay();
		break;
	case 'i':
		state.showIsolines = !state.showIsolines;
		printf("Info: %sshowing isolines\n", state.showIsolines ? "" : "not ");
		glutPostRedisplay();
		break;
	case 'z':
		state.showTesselation = !state.showTesselation;
		printf("Info: %sshowing tesselation result\n", state.showTesselation ? "" : "not ");
		glutPostRedisplay();
		break;
	case '+':
		state.terrainLevelOfDetailPixelThresh *= 2;
		printf("Info: state.terrainLevelOfDetailPixelThresh = %u\n", state.terrainLevelOfDetailPixelThresh);
		glutPostRedisplay();
		break;
	case '-':
		state.terrainLevelOfDetailPixelThresh /= 2;
		if (state.terrainLevelOfDetailPixelThresh < 1)
			state.terrainLevelOfDetailPixelThresh = 1;
		printf("Info: state.terrainLevelOfDetailPixelThresh = %u\n", state.terrainLevelOfDetailPixelThresh);
		glutPostRedisplay();
		break;
	case '*':
		state.terrainPatchGridResolution *= 2;
		printf("Info: state.terrainPatchGridResolution = %u\n", state.terrainPatchGridResolution);
		glutPostRedisplay();
		break;
	case '/':
		state.terrainPatchGridResolution /= 2;
		if (state.terrainPatchGridResolution < 1)
			state.terrainPatchGridResolution = 1;
		printf("Info: state.terrainPatchGridResolution = %u\n", state.terrainPatchGridResolution);
		glutPostRedisplay();
		break;
	case '0':
		if (orbitCamera)
		{
			trackball(curCamquat, 0.0, 0.0, 0.0, 0.0);
			trackball(lastCamquat, 0.0, 0.0, 0.0, 0.0);
		}
		else
		{
			trackball(curquat, 0.0, 0.0, 0.0, 0.0);
			trackball(lastquat, 0.0, 0.0, 0.0, 0.0);
		}
		glutPostRedisplay();
		break;
	}
}

/**
 * callback for refreshing the windows contents
 */

void display(void)
{

	const bool triangleCountEnabled =
		!state.displayFrameCounter && state.terrainTriangleCountEnabled;

	UINT64 timer = PerformanceCounter::Query();

	static float ang = (float)M_PI_2;
	glm::mat4 m;
	glm::mat4 mc;
	build_rotmatrix(m, curquat);
	build_rotmatrix(mc, curCamquat);
	static float camAng = 0.f;
	glm::mat4 matA, matB, modelView;
	float fnear = 0.01f;
	float fov = 45;
	float aspect = (float)state.windowW / (float)state.windowH;
	projMX = glm::perspective(fov, aspect, fnear, 10000.0f);
	float ymax = fnear * float(tan(fov * M_PI / 360.0));
	matA = glm::rotate(glm::mat4(1.0f), camAng, glm::vec3(1.0, 0.0, 0.0));
	matB = glm::rotate(matA, 0.0f, glm::vec3(0.0, 1.0, 0.0));
	matA = matA * matB;
	matB = glm::translate(glm::mat4(1.0f), glm::vec3(0.0f, 0.0f, dolly));
	viewMX = matB * mc;

	modelView = viewMX * m;
	glm::mat4 matMVP = projMX * modelView;

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	if (state.displayWireframe)
	{
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	}
	else
	{
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	}

	//
	// render terrain
	//

	//
	// TODO: look at the following code and try to understand the
	//       terrain rendering pipeline
	//
	//       Exercise a): ignore the tesselation and geometry shader
	//       Exercise b): now the tesselation shader becomes interesting
	//

	if (state.displayTerrain)
	{
		glUseProgram(terrainProg);

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, heightTex);
		glActiveTexture(GL_TEXTURE1);
		glBindTexture(GL_TEXTURE_2D, terrainTex);
		glActiveTexture(GL_TEXTURE2);
		glBindTexture(GL_TEXTURE_2D_ARRAY, state.gl.terrainTexArray);

		GLCE(glUniform2f(glGetUniformLocation(terrainProg, "screen_size"), state.windowW, state.windowH));
		GLCE(glUniform2f(glGetUniformLocation(terrainProg, "planeOrigin"), state.terrainOrigin.x, state.terrainOrigin.y));
		GLCE(glUniform2f(glGetUniformLocation(terrainProg, "planeSize"), state.terrainSize.x, state.terrainSize.y));
		GLCE(glUniform2i(glGetUniformLocation(terrainProg, "planeSubdivs"), state.terrainPatchGridResolution,
						 state.terrainPatchGridResolution));

		GLCE(glUniform1i(glGetUniformLocation(terrainProg, "enableMultiTexturing"), state.enableMultiTexturing));
		GLCE(glUniform1f(glGetUniformLocation(terrainProg, "heightScale"), state.terrainHeightScalingFactor));
		GLCE(glUniform3fv(glGetUniformLocation(terrainProg, "incident"), 1, glm::value_ptr(glm::normalize(glm::vec3(2.0f, 2.0f, 0.5f)))));
		GLCE(glUniform4f(glGetUniformLocation(terrainProg, "light"), 1.0f, 0.95f, 0.9f, 1.0f));
		GLCE(glUniform1f(glGetUniformLocation(terrainProg, "lodPixelTreshold"), float(state.terrainLevelOfDetailPixelThresh)));
		GLCE(glUniformMatrix4fv(glGetUniformLocation(terrainProg, "mvp"), 1, GL_FALSE, glm::value_ptr(matMVP)));
		GLCE(glUniform1i(glGetUniformLocation(terrainProg, "numPatchSubDivisions"), int(state.terrainPatchSubDivisions)));
		GLCE(glUniform1i(glGetUniformLocation(terrainProg, "showIsolines"), state.showIsolines));
		GLCE(glUniform1i(glGetUniformLocation(terrainProg, "showTesselation"), state.showTesselation));
		GLCE(glUniform1i(glGetUniformLocation(terrainProg, "showTexels"), state.showTexels));
		GLCE(glUniform1i(glGetUniformLocation(terrainProg, "lodEnabled"), state.lodEnabled));
		GLCE(glUniform1i(glGetUniformLocation(terrainProg, "terrainHeightmap"), 0));
		GLCE(glUniform1i(glGetUniformLocation(terrainProg, "terrainTex"), 1));
		GLCE(glUniform1i(glGetUniformLocation(terrainProg, "terrainTexArray"), 2));
		GLCE(glUniform1i(glGetUniformLocation(terrainProg, "terrainTextureArraySize"), state.terrainTextureImages.size()));
		GLCE(glUniform1i(glGetUniformLocation(terrainProg, "terrainTextureNumRepeat"), state.terrainTextureNumRepeat));
		GLCE(glUniform4fv(glGetUniformLocation(terrainProg, "terrainTextureWeights"),
						  state.terrainTextureImages.size(), (state.terrainTextureWeights[0].DataPointer())));

		GLCE(glBindVertexArray(flatness));

		//
		// OpenGL Tesselation
		//
		//  Read: The OpenGL Graphics System : A Specification 4.1 (Core Version), Chap. 2.1.2
		//
		//  [..] Tessellation functionality is controlled by two types of tessellation shaders:
		//  tessellation control shaders and tessellation evaluation shaders. Tessellation [..]
		//
		//  > we use both types for the terrain generation
		//

		//
		//  Our terrain shader pipeline:
		//
		//    Terrain Unit Base Quad
		//             |
		//      Vertex Shader (initial subdivision of base quad into regular grid of quad patches,
		//                     we use OpenGL instancing -> see below)
		//             |
		//  Tesselation Control Shader (determine the tesselation subdivision levels
		//             |                on the edges and within the quad patches
		//             |                depending on a level of detail parameter steered by
		//             |                the quad edge size in pixel (measured in the DCS).
		//             |
		//  Tesselation Evaluation Shader (Computes the vertex position and attributes (e.g. texture coordinate)
		//             |                   of the tesselated vertices)
		//             |
		//        Geometry Shader (gathers all vertex attributes
		//             |           and outputs a triangle primitive.
		//                         Note: this is only needed for the debug coloring
		//                         modes in the fragment shader)
		//             |
		//        Fragment Shader (Shading of the terrain)
		//

		// we tesselate "quad patches"
		glPatchParameteri(GL_PATCH_VERTICES, 4);

		// use primitive instancing to set up the
		// initial regular grid of quad patches in
		// the vertex shader.
		if (triangleCountEnabled)
		{
			GLCE(glBeginQuery(GL_PRIMITIVES_GENERATED, state.gl.primitivesGeneratedQuery));
		}

		glDrawArraysInstanced(GL_PATCHES, 0, 4, state.terrainPatchGridResolution * state.terrainPatchGridResolution);

		if (triangleCountEnabled)
		{
			GLCE(glEndQuery(GL_PRIMITIVES_GENERATED));
		}
	}

	//
	// render trees
	//

	if (state.displayTrees)
	{

		GLCE(glUseProgram(treeProg));
		GLint locTexTransparency = glGetUniformLocation(treeProg, "texTransparency");
		glUniform1i(locTexTransparency, 2);
		glActiveTexture(GL_TEXTURE2);
		glBindTexture(GL_TEXTURE_2D, treeTex);

		GLint locInstanceData = glGetUniformLocation(treeProg, "instanceData");
		glUniform1i(locInstanceData, 3);
		glActiveTexture(GL_TEXTURE3);
		glBindTexture(GL_TEXTURE_2D, instanceTex);

		GLint locTerrainData = glGetUniformLocation(treeProg, "terrain");
		glUniform1i(locTerrainData, 4);
		glActiveTexture(GL_TEXTURE4);
		glBindTexture(GL_TEXTURE_2D, heightTex);

		GLCE(glUniform2f(glGetUniformLocation(treeProg, "planeOrigin"), state.terrainOrigin.x, state.terrainOrigin.y));
		GLCE(glUniform2f(glGetUniformLocation(treeProg, "planeSize"), state.terrainSize.x, state.terrainSize.y));
		GLCE(glUniform1f(glGetUniformLocation(treeProg, "heightScale"), state.terrainHeightScalingFactor));
		GLCE(glUniform1i(glGetUniformLocation(treeProg, "sqrtNumInstances"), state.sqrtNumInstances));
		GLCE(glUniform3fv(glGetUniformLocation(treeProg, "incident"), 1, glm::value_ptr(glm::normalize(glm::vec3(2.0f, 2.0f, 0.5f)))));

		GLCE(glUniformMatrix4fv(glGetUniformLocation(treeProg, "model_view"), 1,
								GL_FALSE, glm::value_ptr(modelView)));

		GLCE(glUniformMatrix4fv(glGetUniformLocation(treeProg, "projection"), 1,
								GL_FALSE, glm::value_ptr(projMX)));

		GLCE(glBindVertexArray(treeVA));

		//
		// to allow easy scaling the quads of size 1.0x1.0 are
		// symmetric with respect to the y-axis and are placed
		// on top of the y=0 plane
		//
		// (-0.5,1.0)      (0.5,1.0)
		//           ------
		//           |    |
		//           |    |
		//           ------
		// (-0.5,0.0)      (0.5,0.0)
		//

		GLCE(glDrawArraysInstanced(GL_TRIANGLE_STRIP, 0, 4, state.numInstances));
		GLCE(glDrawArraysInstanced(GL_TRIANGLE_STRIP, 4, 4, state.numInstances));
	}

	//
	// performance counter
	//

	state.frameCounter++;

	if (state.frameCounter == 100)
	{
		UINT64 timer = PerformanceCounter::Query();
		if (state.displayFrameCounter)
		{
			std::cout << "Info: "
					  << (static_cast<double>(timer - state.lastTime) / 100.0)
					  << " ms/frame" << std::endl;
		}
		state.lastTime = timer;
		state.frameCounter = 0;
	}

	GLuint numPrimitives = 0;

	glutSwapBuffers();

	//
	// print the number of generated terrain triangle primitives
	//

	if (triangleCountEnabled)
	{

		GLint available = 0;
		while (!available)
		{
			GLCE(glGetQueryObjectiv(state.gl.primitivesGeneratedQuery, GL_QUERY_RESULT_AVAILABLE, &available));
		}

		GLCE(glGetQueryObjectuiv(state.gl.primitivesGeneratedQuery, GL_QUERY_RESULT, &numPrimitives));
		std::cout << "Info: triangle count = " << numPrimitives << std::endl;
	}
}

/**
 * callback for window resize event
 */
void resize(int w, int h)
{
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
	state.windowW = w;
	state.windowH = h;
}

/**
 * program entry point
 */
#ifdef _WIN32
int _tmain(int argc, _TCHAR *argv[])
{
#else
int main(int argc, char *argv[])
{
#endif

	const std::string progName("glTerrain");

	std::cout << "\n--------------------------------------------------- " << std::endl;
	std::cout << progName << std::endl;
	std::cout << "--------------------------------------------------- " << std::endl;
	std::cout << "Note: Tesselation shader requires Open GL 4.0!" << std::endl;
	std::cout << "--------------------------------------------------- " << std::endl;
	std::cout << "Info: rotate with left mouse button pressed " << std::endl;
	std::cout << "Info: zoom in with shift + left mouse button " << std::endl;
	std::cout << "Info: 'a' enable/disable level of detail terrain geometry " << std::endl;
	std::cout << "Info: 'b' benchmark " << std::endl;
	std::cout << "Info: 'c' enable/disable triangle count " << std::endl;
	std::cout << "Info: 'm' enable/disable multi-texturing " << std::endl;
	std::cout << "Info: 'p/P' decrease/increase quad patch subdivision factor " << std::endl;
	std::cout << "Info: 's/S' decrease/increase terrain height scaling factor " << std::endl;
	std::cout << "Info: 't' show/hide trees " << std::endl;
	std::cout << "Info: 'T' show/hide terrain " << std::endl;
	std::cout << "Info: 'x' show/hide texels " << std::endl;
	std::cout << "Info: 'i' show/hide isolines " << std::endl;
	std::cout << "Info: 'z' show/hide tesselation result " << std::endl;
	std::cout << "Info: 'w' enable/disable wireframe mode " << std::endl;
	std::cout << "Info: '/,*' change initial patch grid resolution " << std::endl;
	std::cout << "Info: '-,+' change level of detail (lod) pixel threshold " << std::endl;
	std::cout << "--------------------------------------------------- " << std::endl;

	int mode = GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH;
	int ac = 0;
	glutInit(&ac, NULL);
	glutInitDisplayMode(mode);
	glutInitContextVersion(4, 1);
	glutInitContextFlags(GLUT_COMPATIBILITY_PROFILE);
	glutInitWindowSize(state.windowW, state.windowH);
	glutCreateWindow(progName.c_str());

	init();
	initGeometry();

	trackball(curquat, 0.0, 0.0, 0.0, 0.0);
	trackball(curCamquat, 0.0, 0.0, 0.0, 0.0);

	glutDisplayFunc(display);
	glutReshapeFunc(resize);
	glutKeyboardFunc(keyboard);
	glutMouseFunc(mouse);
	glutMotionFunc(motion);
	glutIdleFunc(idle);

	std::cout << "Info: initialization finished!" << std::endl;

	glutMainLoop();

	uninit();
}
