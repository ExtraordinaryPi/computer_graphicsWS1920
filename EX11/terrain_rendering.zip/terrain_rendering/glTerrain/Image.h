/*
 * Image.h
 *
 * Copyright (C) 2011 by Universitaet Stuttgart (VIS/US).
 * Alle Rechte vorbehalten.
 */

#ifndef __CG_IMAGE_H__
#define __CG_IMAGE_H__

#include "ppma_io/ppma_io.h"
#include <vector>
#include <iostream>
#include <sstream>
#include <string>

/*
  class for 2D image data (of arbitrary type and number of components)
*/

template <typename T>
class ImageT {
public:

    typedef std::vector<T> ImageData;

    ImageT(unsigned int numComponents)
        : width(0), height(0), numComponents(numComponents) {

    }

    unsigned int Width() { return this->width; };
    unsigned int Height() { return this->height; };
    unsigned int NumComponents() { return this->numComponents; };

    ImageData& GetData() {
        return this->data;
    }

    T* GetDataPointer() {
        return &this->data[0];
    }

    T* GetPixel(unsigned int x, unsigned int y) {
        return &this->data[(x+this->width*y)*this->numComponents];
    }

    void SetPixel(unsigned int x, unsigned int y, unsigned int comp,
        T value) {
            this->data[(x+this->width*y)*this->numComponents+comp] = value;
    }

    void Resize(unsigned int width, unsigned int height) {
        this->width = width;
        this->height = height;
        this->data.resize(this->width*this->height*this->numComponents);
    }

    unsigned int GetHeight() {
        return this->height;
    }

    unsigned int GetWidth() {
        return this->width;
    }

protected:

    unsigned int width;
    unsigned int height;
    unsigned int numComponents;
    ImageData data;

};

/*
  class for 2D image data (float, RGBA)
*/

class ImageRGBAf : public ImageT<float> {

public:

    ImageRGBAf() : ImageT<float>(4) {};

    bool LoadFromPPM(std::string ppmFileName) {

        std::ifstream ppmFile;
        ppmFile.open(ppmFileName.c_str(), std::ifstream::in);
        if (!ppmFile) {
            return false;
        }

        int xSize;
        int ySize;
        int maxRgb;

        if (ppma_read_header(ppmFile, xSize, ySize, maxRgb)) {
            return false;
        }

        const unsigned int numPixels(xSize*ySize);

        std::vector<int> rArray(numPixels);
        std::vector<int> gArray(numPixels);
        std::vector<int> bArray(numPixels);

        if (ppma_read_data(ppmFile, xSize, ySize, 
            &rArray[0], &gArray[0], &bArray[0])) {
                return false;
        }

        this->Resize(xSize, ySize);

        // copy and reverse pixel rows
        for (int y=0; y<ySize; y++) {

            const unsigned int idxOff = xSize*y;
            const unsigned int idxOffR = xSize*(ySize-1-y);

            for (int x=0; x<xSize; x++) {
                data[4*(idxOffR+x)+0] = static_cast<unsigned char>(rArray[idxOff+x])/255.0f;
                data[4*(idxOffR+x)+1] = static_cast<unsigned char>(gArray[idxOff+x])/255.0f;
                data[4*(idxOffR+x)+2] = static_cast<unsigned char>(bArray[idxOff+x])/255.0f;

                // set alpha channel from chroma key RGB = (255, 0, 255)
                if (rArray[idxOff+x]==255 && 
                    gArray[idxOff+x]==0 && 
                    bArray[idxOff+x]==255) {
                        data[4*(idxOffR+x)+3] = 0.0; // transparent 
                } else {
                    data[4*(idxOffR+x)+3] = 1.0; // opaque
                }
            }
        }

        return true;

    }

};


/*
  class for 2D image data (unsigned char, RGBA)
*/

class ImageRGBA : public ImageT<unsigned char> {

public:

    ImageRGBA() : ImageT<unsigned char>(4) {};

    bool LoadFromPPM(std::string ppmFileName) {

        std::ifstream ppmFile;
        ppmFile.open(ppmFileName.c_str(), std::ifstream::in);
        if (!ppmFile) {
            return false;
        }

        int xSize;
        int ySize;
        int maxRgb;

        if (ppma_read_header(ppmFile, xSize, ySize, maxRgb)) {
            return false;
        }

        const unsigned int numPixels(xSize*ySize);

        std::vector<int> rArray(numPixels);
        std::vector<int> gArray(numPixels);
        std::vector<int> bArray(numPixels);

        if (ppma_read_data(ppmFile, xSize, ySize, 
            &rArray[0], &gArray[0], &bArray[0])) {
                return false;
        }

        this->Resize(xSize, ySize);

        // copy and reverse pixel rows
        for (int y=0; y<ySize; y++) {

            const unsigned int idxOff = xSize*y;
            const unsigned int idxOffR = xSize*(ySize-1-y);

            for (int x=0; x<xSize; x++) {
                data[4*(idxOffR+x)+0] = static_cast<unsigned char>(rArray[idxOff+x]);
                data[4*(idxOffR+x)+1] = static_cast<unsigned char>(gArray[idxOff+x]);
                data[4*(idxOffR+x)+2] = static_cast<unsigned char>(bArray[idxOff+x]);

                // set alpha channel from chroma key RGB = (255, 0, 255)
                if (rArray[idxOff+x]==255 && 
                    gArray[idxOff+x]==0 && 
                    bArray[idxOff+x]==255) {
                        data[4*(idxOffR+x)+3] = 0; // transparent 
                } else {
                    data[4*(idxOffR+x)+3] = 255; // opaque
                }
            }
        }

        return true;

    }

};


/*
  class for mipmap images (ImageRGBAf)
*/

class MipMapImageRGBAf : std::vector<ImageRGBAf> {
 public:

  unsigned int GetNumLevels() {
    return this->size();
  }

  ImageRGBAf& GetLevel(unsigned int lvl) {
    return this->operator[](lvl);
  }

  void SetNumLevels(unsigned int numLevels) {
    this->resize(numLevels);
  }

  std::string GetInfoString() {
    std::ostringstream os;
    for (unsigned int lvl=0; lvl<this->GetNumLevels(); lvl++) {
      os << "level " << lvl << ": " 
         << this->GetLevel(lvl).GetWidth() << "x" 
         << this->GetLevel(lvl).GetHeight() << std::endl; 
    }
    return os.str();
  }

};


#endif /* __CG_IMAGE_H__ */
