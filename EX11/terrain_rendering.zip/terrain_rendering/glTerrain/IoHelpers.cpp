#define _CRT_SECURE_NO_WARNINGS 1

#include "IoHelpers.h"
#include <stdio.h>
#include <float.h>
#include <math.h>
#include <cmath>
#include <algorithm>

#ifndef _WIN32
#include <GL/freeglut.h>
#ifndef _isnan
#define _isnan isnan
#endif

#ifndef _finite
#define _finite finite
#endif

#endif /* !_WIN32 */

#ifdef max
#undef max
#endif

char *loadRAW(const char *filename, GLuint &width, GLuint &height, GLuint &channels) {
    FILE *file = fopen(filename, "rb");
    char *buf;

    if (file != NULL) {
        fread(&width, sizeof(unsigned int), 1, file);
        fread(&height, sizeof(unsigned int), 1, file);
        fread(&channels, sizeof(unsigned int), 1, file);

        buf = new char[width * height * channels];
        if (fread(buf, channels, width * height, file) != width * height) {
            int e = ferror(file);
            printf("file error %u\n", e);
        }
        fclose(file);
        return buf;
    }
    return NULL;
}

float *loadHeightField(const char *filename, GLuint &width, GLuint &height, GLuint &channels) {
    FILE *file = fopen(filename, "rb");
    float *buf;

    if (file != NULL) {
        fread(&width, sizeof(unsigned int), 1, file);
        fread(&height, sizeof(unsigned int), 1, file);
        fread(&channels, sizeof(unsigned int), 1, file);

        buf = new float[width * height];
        if (fread(buf, sizeof(float), width * height, file) != width * height) {
            int e = ferror(file);
            printf("file error %u\n", e);
        }
        fclose(file);
        float min = FLT_MAX;
        float max = -FLT_MAX;
        unsigned int numNaN = 0;
        unsigned int numInf = 0;
        float *f = (float*)buf;
        while (f < &((float*)buf)[width * height]) {
            if (_isnan(*f)) numNaN++;
            if (!_finite(*f)) numInf++;
            if (*f < min) min = *f;
            if (fabs(*f) > max) max = fabs(*f);
            f++;
        }
        f = (float*)buf;
        while (f < &((float*)buf)[width * height]) {
            // this would normalize the whole range into [0,1]
            //*f -= min;
            //*f /= (max - min);
            // but like this, the higher/lower of both extremes is used to
            // scale everything around a constant 0 level
		  *f /= std::max(max, std::abs(min));
            // flatten sub-sealevel geometry because we cannot render water and fish
            if (*f < 0.0f)
                *f = 0.0f;
            f++;
        }

        return buf;
    }
    return NULL;
}
